
import React, { useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const movies = [
  {
    title: "Pathaan",
    year: 2023,
    language: "Hindi + English",
    poster: "https://upload.wikimedia.org/wikipedia/en/thumb/f/f7/Pathaan_film_poster.jpg/220px-Pathaan_film_poster.jpg",
  },
  {
    title: "John Wick 4",
    year: 2023,
    language: "English + Hindi",
    poster: "https://upload.wikimedia.org/wikipedia/en/6/60/John_Wick_-_Chapter_4_poster.jpg",
  },
  {
    title: "Jawan",
    year: 2023,
    language: "Hindi + English",
    poster: "https://upload.wikimedia.org/wikipedia/en/9/93/Jawan_film_poster.jpg",
  },
];

export default function MovieSite() {
  useEffect(() => {
    document.title = "Movieshub.com - Latest Dual Audio Movies";
    alert("Welcome to Movieshub.com - Stream or Download the Latest Movies!");
  }, []);

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <header className="text-center py-6">
        <h1 className="text-4xl font-bold text-red-500">Movieshub.com</h1>
        <p className="text-lg mt-2 text-gray-300">
          Latest Bollywood & Hollywood Movies in Hindi + English
        </p>
        <div className="mt-4 max-w-md mx-auto">
          <Input placeholder="Search movies..." className="bg-gray-800 border-none" />
        </div>
      </header>

      <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 mt-6">
        {movies.map((movie, index) => (
          <Card key={index} className="bg-gray-900">
            <CardContent className="p-4">
              <img
                src={movie.poster}
                alt={movie.title}
                className="w-full h-64 object-cover rounded-lg mb-4"
              />
              <h2 className="text-xl font-semibold text-white">{movie.title}</h2>
              <p className="text-gray-400 text-sm">Year: {movie.year}</p>
              <p className="text-gray-400 text-sm">Audio: {movie.language}</p>
              <Button className="mt-4 w-full bg-red-600 hover:bg-red-700">
                Download / Watch
              </Button>
            </CardContent>
          </Card>
        ))}
      </section>

      <footer className="text-center text-gray-500 mt-10 text-sm">
        © 2025 Movieshub.com. Designed for educational/demo use only.
      </footer>
    </div>
  );
}
